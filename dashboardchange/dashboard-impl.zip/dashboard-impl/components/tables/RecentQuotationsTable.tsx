// components/dashboard/tables/RecentQuotationsTable.tsx
// 최근 견적서 테이블

'use client';

import { useRecentQuotations } from '@/hooks/useDashboard';
import { PROGRESS_LABELS } from '@/types/dashboard';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { formatCurrencyFull } from '../widgets/SummaryCard';
import { format } from 'date-fns';
import { ko } from 'date-fns/locale';
import Link from 'next/link';
import { ExternalLink } from 'lucide-react';

interface RecentQuotationsTableProps {
  userId?: string;
  limit?: number;
}

export default function RecentQuotationsTable({ userId, limit = 5 }: RecentQuotationsTableProps) {
  const { data, isLoading } = useRecentQuotations(limit);

  // 로딩 상태
  if (isLoading) {
    return (
      <div className="space-y-2">
        {[1, 2, 3, 4, 5].map((i) => (
          <Skeleton key={i} className="h-12 w-full" />
        ))}
      </div>
    );
  }

  // 데이터가 없는 경우
  if (!data?.quotations?.length) {
    return (
      <div className="text-center py-8 text-gray-500">
        최근 견적서가 없습니다.
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-gray-50">
            <TableHead>견적번호</TableHead>
            <TableHead>고객사</TableHead>
            <TableHead>유형</TableHead>
            <TableHead className="text-right">금액</TableHead>
            <TableHead>상태</TableHead>
            <TableHead>진행상태</TableHead>
            <TableHead>작성일</TableHead>
            <TableHead className="w-[50px]"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.quotations.map((quotation: any) => (
            <TableRow key={quotation.id} className="hover:bg-gray-50">
              {/* 견적번호 */}
              <TableCell className="font-mono text-sm">
                {quotation.quotationNumber}
              </TableCell>
              
              {/* 고객사 */}
              <TableCell className="font-medium">
                {quotation.customerName || quotation.customer?.name || '-'}
              </TableCell>
              
              {/* 유형 */}
              <TableCell>
                <TypeBadge type={quotation.type} />
              </TableCell>
              
              {/* 금액 */}
              <TableCell className="text-right font-medium">
                {formatCurrencyFull(quotation.totalAmount || 0)}
              </TableCell>
              
              {/* 상태 */}
              <TableCell>
                <StatusBadge status={quotation.status} />
              </TableCell>
              
              {/* 진행상태 */}
              <TableCell>
                {quotation.progressStatus ? (
                  <ProgressBadge progress={quotation.progressStatus} />
                ) : (
                  <span className="text-gray-400">-</span>
                )}
              </TableCell>
              
              {/* 작성일 */}
              <TableCell className="text-gray-500 text-sm">
                {format(new Date(quotation.createdAt), 'MM.dd', { locale: ko })}
              </TableCell>
              
              {/* 링크 */}
              <TableCell>
                <Link 
                  href={`/quotations/${quotation.id}`}
                  className="text-blue-600 hover:text-blue-800"
                >
                  <ExternalLink className="h-4 w-4" />
                </Link>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

// 유형 뱃지
function TypeBadge({ type }: { type: string }) {
  const config: Record<string, { label: string; className: string }> = {
    TOXICITY: { label: '독성', className: 'bg-red-100 text-red-700' },
    EFFICACY: { label: '효력', className: 'bg-blue-100 text-blue-700' },
    CLINICAL_PATHOLOGY: { label: '임병', className: 'bg-purple-100 text-purple-700' },
  };

  const { label, className } = config[type] || { label: type, className: 'bg-gray-100 text-gray-700' };

  return (
    <span className={`inline-flex px-2 py-0.5 rounded text-xs font-medium ${className}`}>
      {label}
    </span>
  );
}

// 상태 뱃지
function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline' }> = {
    DRAFT: { label: '작성중', variant: 'secondary' },
    SUBMITTED: { label: '제출', variant: 'default' },
    SENT: { label: '발송', variant: 'default' },
    WON: { label: '수주', variant: 'default' },
    LOST: { label: '실주', variant: 'destructive' },
  };

  const { label, variant } = config[status] || { label: status, variant: 'outline' as const };

  return <Badge variant={variant}>{label}</Badge>;
}

// 진행상태 뱃지
function ProgressBadge({ progress }: { progress: string }) {
  const label = PROGRESS_LABELS[progress as keyof typeof PROGRESS_LABELS] || progress;
  
  const colorMap: Record<string, string> = {
    BUDGET_SECURED: 'bg-amber-100 text-amber-700',
    ON_HOLD: 'bg-gray-100 text-gray-700',
    WITH_COMPETITOR: 'bg-red-100 text-red-700',
    IN_PROGRESS: 'bg-blue-100 text-blue-700',
    NEGOTIATING: 'bg-purple-100 text-purple-700',
    WON: 'bg-green-100 text-green-700',
    LOST: 'bg-red-100 text-red-700',
  };

  const className = colorMap[progress] || 'bg-gray-100 text-gray-700';

  return (
    <span className={`inline-flex px-2 py-0.5 rounded text-xs font-medium ${className}`}>
      {label}
    </span>
  );
}
