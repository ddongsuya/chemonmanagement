// components/dashboard/tables/UserRankingTable.tsx
// 담당자별 순위 테이블

'use client';

import { UserDashboardData } from '@/types/dashboard';
import { POSITION_LABELS, TITLE_LABELS } from '@/lib/auth/dashboard-permissions';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { formatCurrency, formatPercent } from '../widgets/SummaryCard';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Medal } from 'lucide-react';

interface UserRankingTableProps {
  data: UserDashboardData[];
}

export default function UserRankingTable({ data }: UserRankingTableProps) {
  // 데이터가 없는 경우
  if (!data.length) {
    return (
      <div className="text-center py-8 text-gray-500">
        데이터가 없습니다.
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-gray-50">
            <TableHead className="w-[60px]">순위</TableHead>
            <TableHead>담당자</TableHead>
            <TableHead>소속</TableHead>
            <TableHead className="text-right">견적금액</TableHead>
            <TableHead className="text-right">견적수</TableHead>
            <TableHead className="text-right">계약금액</TableHead>
            <TableHead className="text-right">계약율</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((user, index) => (
            <TableRow key={user.userId} className="hover:bg-gray-50">
              {/* 순위 */}
              <TableCell>
                <RankBadge rank={index + 1} />
              </TableCell>
              
              {/* 담당자 */}
              <TableCell>
                <div className="flex items-center gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="bg-blue-100 text-blue-700 text-xs">
                      {user.userName.slice(0, 2)}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-medium">{user.userName}</p>
                    <p className="text-xs text-gray-500">
                      {POSITION_LABELS[user.position as keyof typeof POSITION_LABELS] || user.position}
                      {' / '}
                      {TITLE_LABELS[user.title as keyof typeof TITLE_LABELS] || user.title}
                    </p>
                  </div>
                </div>
              </TableCell>
              
              {/* 소속 */}
              <TableCell className="text-gray-600">
                {user.departmentName}
              </TableCell>
              
              {/* 견적금액 */}
              <TableCell className="text-right font-medium text-blue-600">
                {formatCurrency(user.data.quotation.totalAmount)}
              </TableCell>
              
              {/* 견적수 */}
              <TableCell className="text-right">
                {user.data.quotation.totalCount}건
              </TableCell>
              
              {/* 계약금액 */}
              <TableCell className="text-right font-medium text-green-600">
                {formatCurrency(user.data.contract.totalAmount)}
              </TableCell>
              
              {/* 계약율 */}
              <TableCell className="text-right">
                <span className={`font-medium ${user.data.kpi.conversionRate >= 30 ? 'text-green-600' : 'text-gray-600'}`}>
                  {formatPercent(user.data.kpi.conversionRate)}
                </span>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

// 순위 뱃지
function RankBadge({ rank }: { rank: number }) {
  if (rank === 1) {
    return (
      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-yellow-100">
        <Medal className="h-5 w-5 text-yellow-600" />
      </div>
    );
  }
  if (rank === 2) {
    return (
      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-200">
        <Medal className="h-5 w-5 text-gray-500" />
      </div>
    );
  }
  if (rank === 3) {
    return (
      <div className="flex items-center justify-center w-8 h-8 rounded-full bg-orange-100">
        <Medal className="h-5 w-5 text-orange-500" />
      </div>
    );
  }
  
  return (
    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-gray-100">
      <span className="text-sm font-medium text-gray-600">{rank}</span>
    </div>
  );
}
