// components/dashboard/tables/DepartmentTable.tsx
// 센터별 현황 테이블

'use client';

import { DepartmentDashboardData } from '@/types/dashboard';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { formatCurrency, formatPercent } from '../widgets/SummaryCard';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface DepartmentTableProps {
  data: DepartmentDashboardData[];
}

export default function DepartmentTable({ data }: DepartmentTableProps) {
  // 견적금액 기준 정렬
  const sortedData = [...data].sort(
    (a, b) => b.data.quotation.totalAmount - a.data.quotation.totalAmount
  );

  // 데이터가 없는 경우
  if (!data.length) {
    return (
      <div className="text-center py-8 text-gray-500">
        데이터가 없습니다.
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-gray-50">
            <TableHead className="w-[160px]">센터/팀</TableHead>
            <TableHead className="text-right">견적금액</TableHead>
            <TableHead className="text-right">견적수</TableHead>
            <TableHead className="text-right">계약금액</TableHead>
            <TableHead className="text-right">계약수</TableHead>
            <TableHead className="text-right">계약율</TableHead>
            <TableHead className="text-right">진행중</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sortedData.map((dept, index) => (
            <TableRow key={dept.departmentId} className="hover:bg-gray-50">
              {/* 센터명 */}
              <TableCell className="font-medium">
                <div className="flex items-center gap-2">
                  <span className="text-gray-400 text-sm">{index + 1}</span>
                  {dept.departmentName}
                </div>
              </TableCell>
              
              {/* 견적금액 */}
              <TableCell className="text-right font-medium text-blue-600">
                {formatCurrency(dept.data.quotation.totalAmount)}
              </TableCell>
              
              {/* 견적수 */}
              <TableCell className="text-right">
                {dept.data.quotation.totalCount}건
              </TableCell>
              
              {/* 계약금액 */}
              <TableCell className="text-right font-medium text-green-600">
                {formatCurrency(dept.data.contract.totalAmount)}
              </TableCell>
              
              {/* 계약수 */}
              <TableCell className="text-right">
                {dept.data.contract.totalCount}건
              </TableCell>
              
              {/* 계약율 */}
              <TableCell className="text-right">
                <ConversionRateBadge rate={dept.data.kpi.conversionRate} />
              </TableCell>
              
              {/* 진행중 */}
              <TableCell className="text-right">
                <Badge variant="outline" className="font-normal">
                  {dept.data.progress.inProgress + dept.data.progress.negotiating}건
                </Badge>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

// 계약율 뱃지
function ConversionRateBadge({ rate }: { rate: number }) {
  const getVariant = () => {
    if (rate >= 30) return 'bg-green-100 text-green-700';
    if (rate >= 20) return 'bg-yellow-100 text-yellow-700';
    if (rate >= 10) return 'bg-orange-100 text-orange-700';
    return 'bg-gray-100 text-gray-700';
  };

  const getIcon = () => {
    if (rate >= 30) return <TrendingUp className="h-3 w-3" />;
    if (rate >= 20) return <Minus className="h-3 w-3" />;
    return <TrendingDown className="h-3 w-3" />;
  };

  return (
    <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${getVariant()}`}>
      {getIcon()}
      {formatPercent(rate)}
    </span>
  );
}
