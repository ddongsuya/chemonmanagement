// components/dashboard/filters/PeriodFilter.tsx
// 기간 필터 컴포넌트 (월별/주별/분기별)

'use client';

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { PeriodType } from '@/types/dashboard';
import { Calendar, CalendarDays, CalendarRange } from 'lucide-react';

interface PeriodFilterProps {
  periodType: PeriodType;
  year: number;
  month?: number;
  quarter?: number;
  onPeriodTypeChange: (type: PeriodType) => void;
  onYearChange: (year: number) => void;
  onMonthChange: (month: number) => void;
  onQuarterChange: (quarter: number) => void;
}

export default function PeriodFilter({
  periodType,
  year,
  month,
  quarter,
  onPeriodTypeChange,
  onYearChange,
  onMonthChange,
  onQuarterChange,
}: PeriodFilterProps) {
  // 년도 옵션 (현재 년도 기준 ±2년)
  const currentYear = new Date().getFullYear();
  const years = [currentYear - 2, currentYear - 1, currentYear, currentYear + 1];

  // 월 옵션
  const months = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];

  // 분기 옵션
  const quarters = [
    { value: 1, label: '1분기 (1~3월)' },
    { value: 2, label: '2분기 (4~6월)' },
    { value: 3, label: '3분기 (7~9월)' },
    { value: 4, label: '4분기 (10~12월)' },
  ];

  return (
    <div className="flex flex-wrap items-center gap-2">
      {/* 기간 유형 선택 */}
      <Select value={periodType} onValueChange={(v) => onPeriodTypeChange(v as PeriodType)}>
        <SelectTrigger className="w-[120px]">
          <div className="flex items-center gap-2">
            {periodType === 'monthly' && <Calendar className="h-4 w-4" />}
            {periodType === 'weekly' && <CalendarDays className="h-4 w-4" />}
            {periodType === 'quarterly' && <CalendarRange className="h-4 w-4" />}
            <SelectValue />
          </div>
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="monthly">
            <div className="flex items-center gap-2">
              <Calendar className="h-4 w-4" />
              월별
            </div>
          </SelectItem>
          <SelectItem value="weekly">
            <div className="flex items-center gap-2">
              <CalendarDays className="h-4 w-4" />
              주별
            </div>
          </SelectItem>
          <SelectItem value="quarterly">
            <div className="flex items-center gap-2">
              <CalendarRange className="h-4 w-4" />
              분기별
            </div>
          </SelectItem>
        </SelectContent>
      </Select>

      {/* 년도 선택 */}
      <Select value={year.toString()} onValueChange={(v) => onYearChange(parseInt(v))}>
        <SelectTrigger className="w-[100px]">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {years.map((y) => (
            <SelectItem key={y} value={y.toString()}>
              {y}년
            </SelectItem>
          ))}
        </SelectContent>
      </Select>

      {/* 월 선택 (월별/주별) */}
      {(periodType === 'monthly' || periodType === 'weekly') && (
        <Select
          value={month?.toString() || '1'}
          onValueChange={(v) => onMonthChange(parseInt(v))}
        >
          <SelectTrigger className="w-[90px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {months.map((m) => (
              <SelectItem key={m} value={m.toString()}>
                {m}월
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}

      {/* 분기 선택 (분기별) */}
      {periodType === 'quarterly' && (
        <Select
          value={quarter?.toString() || '1'}
          onValueChange={(v) => onQuarterChange(parseInt(v))}
        >
          <SelectTrigger className="w-[140px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {quarters.map((q) => (
              <SelectItem key={q.value} value={q.value.toString()}>
                {q.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      )}
    </div>
  );
}
