// components/dashboard/Dashboard.tsx
// 대시보드 메인 컴포넌트 - 권한별 분기

'use client';

import { useState } from 'react';
import { useDashboard } from '@/hooks/useDashboard';
import { PeriodType } from '@/types/dashboard';
import PersonalDashboard from './views/PersonalDashboard';
import TeamDashboard from './views/TeamDashboard';
import CompanyDashboard from './views/CompanyDashboard';
import PeriodFilter from './filters/PeriodFilter';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { AlertCircle } from 'lucide-react';

export default function Dashboard() {
  // 기간 필터 상태
  const [periodType, setPeriodType] = useState<PeriodType>('monthly');
  const [year, setYear] = useState(new Date().getFullYear());
  const [month, setMonth] = useState(new Date().getMonth() + 1);
  const [quarter, setQuarter] = useState(Math.ceil((new Date().getMonth() + 1) / 3));

  // 대시보드 데이터 조회
  const { data, isLoading, error } = useDashboard({
    periodType,
    year,
    month,
    quarter,
  });

  // 로딩 상태
  if (isLoading) {
    return <DashboardSkeleton />;
  }

  // 에러 상태
  if (error || !data) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          대시보드 데이터를 불러오는 중 오류가 발생했습니다.
        </AlertDescription>
      </Alert>
    );
  }

  return (
    <div className="space-y-6">
      {/* 헤더 */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">대시보드</h1>
          <p className="text-gray-500 mt-1">
            {data.accessLevel === 'FULL' && '전사 현황'}
            {data.accessLevel === 'TEAM' && `${data.user.departmentName || '부서'} 현황`}
            {data.accessLevel === 'PERSONAL' && '내 현황'}
            {' | '}
            {data.user.name}님
          </p>
        </div>

        {/* 기간 필터 */}
        <PeriodFilter
          periodType={periodType}
          year={year}
          month={month}
          quarter={quarter}
          onPeriodTypeChange={setPeriodType}
          onYearChange={setYear}
          onMonthChange={setMonth}
          onQuarterChange={setQuarter}
        />
      </div>

      {/* 권한별 대시보드 */}
      {data.accessLevel === 'FULL' && data.company ? (
        <CompanyDashboard 
          data={data.company} 
          personalData={data.personal}
          user={data.user}
        />
      ) : data.accessLevel === 'TEAM' && data.team ? (
        <TeamDashboard 
          teamData={data.team} 
          personalData={data.personal}
          user={data.user}
        />
      ) : (
        <PersonalDashboard 
          data={data.personal}
          user={data.user}
        />
      )}
    </div>
  );
}

// 로딩 스켈레톤
function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      {/* 헤더 스켈레톤 */}
      <div className="flex justify-between items-center">
        <div>
          <Skeleton className="h-8 w-32" />
          <Skeleton className="h-4 w-48 mt-2" />
        </div>
        <Skeleton className="h-10 w-64" />
      </div>

      {/* 카드 스켈레톤 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-32 rounded-lg" />
        ))}
      </div>

      {/* 차트 스켈레톤 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Skeleton className="h-80 rounded-lg" />
        <Skeleton className="h-80 rounded-lg" />
      </div>

      {/* 테이블 스켈레톤 */}
      <Skeleton className="h-64 rounded-lg" />
    </div>
  );
}
