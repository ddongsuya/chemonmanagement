// components/dashboard/widgets/WeeklyTrendChart.tsx
// 주차별 견적/계약 추이 라인 차트

'use client';

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { WeeklyData } from '@/types/dashboard';

interface WeeklyTrendChartProps {
  quotationData: WeeklyData[];
  contractData: WeeklyData[];
}

export default function WeeklyTrendChart({ quotationData, contractData }: WeeklyTrendChartProps) {
  // 데이터 병합
  const chartData = quotationData.map((q, index) => ({
    week: `${q.week}주차`,
    견적: q.amount,
    계약: contractData[index]?.amount || 0,
    견적건수: q.count,
    계약건수: contractData[index]?.count || 0,
  }));

  // 금액 포맷
  const formatAmount = (value: number) => {
    if (value >= 100000000) {
      return `${(value / 100000000).toFixed(1)}억`;
    }
    if (value >= 10000) {
      return `${(value / 10000).toFixed(0)}만`;
    }
    return value.toLocaleString();
  };

  // 커스텀 툴팁
  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-white border border-gray-200 rounded-lg shadow-lg p-3">
          <p className="font-medium text-gray-900 mb-2">{label}</p>
          {payload.map((entry: any, index: number) => (
            <div key={index} className="flex items-center gap-2 text-sm">
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: entry.color }}
              />
              <span className="text-gray-600">{entry.name}:</span>
              <span className="font-medium">{formatAmount(entry.value)}</span>
              <span className="text-gray-400">
                ({entry.name === '견적' ? payload[0]?.payload?.견적건수 : payload[0]?.payload?.계약건수}건)
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  // 데이터가 없는 경우
  if (!chartData.length) {
    return (
      <div className="h-64 flex items-center justify-center text-gray-500">
        데이터가 없습니다.
      </div>
    );
  }

  return (
    <div className="h-64">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
          <XAxis 
            dataKey="week" 
            tick={{ fontSize: 12, fill: '#6B7280' }}
            axisLine={{ stroke: '#E5E7EB' }}
          />
          <YAxis
            tickFormatter={formatAmount}
            tick={{ fontSize: 12, fill: '#6B7280' }}
            axisLine={{ stroke: '#E5E7EB' }}
          />
          <Tooltip content={<CustomTooltip />} />
          <Legend 
            wrapperStyle={{ paddingTop: '10px' }}
            iconType="circle"
          />
          <Line
            type="monotone"
            dataKey="견적"
            stroke="#3B82F6"
            strokeWidth={2}
            dot={{ fill: '#3B82F6', strokeWidth: 2, r: 4 }}
            activeDot={{ r: 6 }}
          />
          <Line
            type="monotone"
            dataKey="계약"
            stroke="#10B981"
            strokeWidth={2}
            dot={{ fill: '#10B981', strokeWidth: 2, r: 4 }}
            activeDot={{ r: 6 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
