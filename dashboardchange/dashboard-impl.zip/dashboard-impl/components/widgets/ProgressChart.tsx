// components/dashboard/widgets/ProgressChart.tsx
// 진행 현황 가로 막대 차트

'use client';

import { ProgressData, PROGRESS_LABELS, PROGRESS_COLORS } from '@/types/dashboard';
import { QuotationProgress } from '@prisma/client';

interface ProgressChartProps {
  data: ProgressData;
}

export default function ProgressChart({ data }: ProgressChartProps) {
  // 데이터 배열로 변환
  const progressItems = [
    { key: 'BUDGET_SECURED' as QuotationProgress, label: PROGRESS_LABELS.BUDGET_SECURED, count: data.budgetSecured, color: PROGRESS_COLORS.BUDGET_SECURED },
    { key: 'ON_HOLD' as QuotationProgress, label: PROGRESS_LABELS.ON_HOLD, count: data.onHold, color: PROGRESS_COLORS.ON_HOLD },
    { key: 'WITH_COMPETITOR' as QuotationProgress, label: PROGRESS_LABELS.WITH_COMPETITOR, count: data.withCompetitor, color: PROGRESS_COLORS.WITH_COMPETITOR },
    { key: 'IN_PROGRESS' as QuotationProgress, label: PROGRESS_LABELS.IN_PROGRESS, count: data.inProgress, color: PROGRESS_COLORS.IN_PROGRESS },
    { key: 'NEGOTIATING' as QuotationProgress, label: PROGRESS_LABELS.NEGOTIATING, count: data.negotiating, color: PROGRESS_COLORS.NEGOTIATING },
    { key: 'WON' as QuotationProgress, label: PROGRESS_LABELS.WON, count: data.won, color: PROGRESS_COLORS.WON },
    { key: 'LOST' as QuotationProgress, label: PROGRESS_LABELS.LOST, count: data.lost, color: PROGRESS_COLORS.LOST },
  ];

  // 최대값 계산 (막대 너비 비율용)
  const maxCount = Math.max(...progressItems.map(item => item.count), 1);

  // 총 건수
  const totalCount = progressItems.reduce((sum, item) => sum + item.count, 0);

  // 데이터가 없는 경우
  if (totalCount === 0) {
    return (
      <div className="h-64 flex items-center justify-center text-gray-500">
        진행 중인 건이 없습니다.
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {progressItems.map((item) => (
        <div key={item.key} className="flex items-center gap-3">
          {/* 라벨 */}
          <div className="w-24 text-sm text-gray-600 truncate">
            {item.label}
          </div>
          
          {/* 막대 */}
          <div className="flex-1 h-6 bg-gray-100 rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-500 ease-out"
              style={{
                width: `${(item.count / maxCount) * 100}%`,
                backgroundColor: item.color,
                minWidth: item.count > 0 ? '20px' : '0',
              }}
            />
          </div>
          
          {/* 건수 */}
          <div className="w-12 text-sm font-medium text-gray-900 text-right">
            {item.count}건
          </div>
        </div>
      ))}
      
      {/* 총계 */}
      <div className="pt-3 border-t border-gray-200 flex justify-between">
        <span className="text-sm text-gray-500">총계</span>
        <span className="text-sm font-bold text-gray-900">{totalCount}건</span>
      </div>
    </div>
  );
}
