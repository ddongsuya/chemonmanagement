// components/dashboard/widgets/SummaryCard.tsx
// 대시보드 요약 카드 위젯

'use client';

import { ReactNode } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { cn } from '@/lib/utils';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface SummaryCardProps {
  title: string;
  value: string | number;
  subValue?: string;
  icon?: ReactNode;
  trend?: {
    value: number;
    type: 'increase' | 'decrease' | 'neutral';
  };
  highlight?: boolean;
  className?: string;
}

export default function SummaryCard({
  title,
  value,
  subValue,
  icon,
  trend,
  highlight,
  className,
}: SummaryCardProps) {
  return (
    <Card className={cn(
      'relative overflow-hidden transition-all hover:shadow-md',
      highlight && 'ring-2 ring-green-500',
      className
    )}>
      <CardContent className="p-6">
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            {/* 제목 */}
            <p className="text-sm font-medium text-gray-500">{title}</p>
            
            {/* 메인 값 */}
            <p className="text-2xl font-bold text-gray-900">{value}</p>
            
            {/* 서브 값 & 트렌드 */}
            <div className="flex items-center gap-2">
              {subValue && (
                <span className="text-sm text-gray-500">{subValue}</span>
              )}
              
              {trend && (
                <span className={cn(
                  'flex items-center text-xs font-medium',
                  trend.type === 'increase' && 'text-green-600',
                  trend.type === 'decrease' && 'text-red-600',
                  trend.type === 'neutral' && 'text-gray-500'
                )}>
                  {trend.type === 'increase' && <TrendingUp className="h-3 w-3 mr-0.5" />}
                  {trend.type === 'decrease' && <TrendingDown className="h-3 w-3 mr-0.5" />}
                  {trend.type === 'neutral' && <Minus className="h-3 w-3 mr-0.5" />}
                  {trend.value > 0 ? '+' : ''}{trend.value}%
                </span>
              )}
            </div>
          </div>
          
          {/* 아이콘 */}
          {icon && (
            <div className="rounded-full bg-blue-50 p-3 text-blue-600">
              {icon}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

// =====================
// 포맷팅 유틸리티
// =====================

/**
 * 금액 포맷 (억 단위)
 */
export function formatCurrency(amount: number): string {
  if (amount >= 100000000) {
    const billions = amount / 100000000;
    return `${billions.toFixed(1)}억`;
  }
  if (amount >= 10000000) {
    const millions = amount / 10000000;
    return `${millions.toFixed(1)}천만`;
  }
  if (amount >= 10000) {
    const thousands = amount / 10000;
    return `${thousands.toFixed(0)}만`;
  }
  return amount.toLocaleString() + '원';
}

/**
 * 금액 포맷 (상세, 원 단위)
 */
export function formatCurrencyFull(amount: number): string {
  return amount.toLocaleString() + '원';
}

/**
 * 퍼센트 포맷
 */
export function formatPercent(value: number): string {
  return `${value.toFixed(1)}%`;
}

/**
 * 트렌드 계산 (주차별 데이터 기반)
 */
export function calculateTrend(weeklyData: Array<{ amount: number }>): {
  value: number;
  type: 'increase' | 'decrease' | 'neutral';
} {
  if (weeklyData.length < 2) {
    return { value: 0, type: 'neutral' };
  }
  
  const lastWeek = weeklyData[weeklyData.length - 1]?.amount || 0;
  const prevWeek = weeklyData[weeklyData.length - 2]?.amount || 0;
  
  if (prevWeek === 0) {
    return lastWeek > 0 
      ? { value: 100, type: 'increase' } 
      : { value: 0, type: 'neutral' };
  }
  
  const change = ((lastWeek - prevWeek) / prevWeek) * 100;
  
  return {
    value: Math.round(change * 10) / 10,
    type: change > 0 ? 'increase' : change < 0 ? 'decrease' : 'neutral',
  };
}
