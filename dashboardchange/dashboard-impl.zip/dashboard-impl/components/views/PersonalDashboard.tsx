// components/dashboard/views/PersonalDashboard.tsx
// 개인 대시보드 (PERSONAL 권한 - 일반 USER)

'use client';

import { DashboardData } from '@/types/dashboard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import SummaryCard, { formatCurrency, formatPercent, calculateTrend } from '../widgets/SummaryCard';
import WeeklyTrendChart from '../widgets/WeeklyTrendChart';
import ProgressChart from '../widgets/ProgressChart';
import RecentQuotationsTable from '../tables/RecentQuotationsTable';
import { 
  FileText, 
  FileStack, 
  Handshake, 
  TrendingUp,
  Sparkles,
} from 'lucide-react';

interface PersonalDashboardProps {
  data: DashboardData;
  user: {
    id: string;
    name: string;
    departmentName: string | null;
  };
}

export default function PersonalDashboard({ data, user }: PersonalDashboardProps) {
  // 인사 메시지
  const greeting = getGreeting();

  return (
    <div className="space-y-6">
      {/* 인사 */}
      <div className="flex items-center gap-2">
        <Sparkles className="h-5 w-5 text-yellow-500" />
        <p className="text-gray-600">
          {user.name}님, {greeting}!
        </p>
      </div>

      {/* 요약 카드 4개 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <SummaryCard
          title="내 견적 금액"
          value={formatCurrency(data.quotation.totalAmount)}
          subValue={`당월 ${formatCurrency(data.quotation.currentPeriodAmount)}`}
          icon={<FileText className="h-5 w-5" />}
          trend={calculateTrend(data.quotation.weeklyData)}
        />

        <SummaryCard
          title="내 견적서 수"
          value={`${data.quotation.totalCount}건`}
          subValue={`독성 ${data.quotation.byType.toxicity.count} / 효력 ${data.quotation.byType.efficacy.count} / 임병 ${data.quotation.byType.clinicalPathology.count}`}
          icon={<FileStack className="h-5 w-5" />}
        />

        <SummaryCard
          title="내 계약 금액"
          value={formatCurrency(data.contract.totalAmount)}
          subValue={`당월 ${formatCurrency(data.contract.currentPeriodAmount)}`}
          icon={<Handshake className="h-5 w-5" />}
          trend={calculateTrend(data.contract.weeklyData)}
        />

        <SummaryCard
          title="내 계약율"
          value={formatPercent(data.kpi.conversionRate)}
          subValue={`평균 계약금액 ${formatCurrency(data.kpi.avgDealSize)}`}
          icon={<TrendingUp className="h-5 w-5" />}
          highlight={data.kpi.conversionRate >= 30}
        />
      </div>

      {/* 차트 2개 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 주차별 추이 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">주차별 추이</CardTitle>
          </CardHeader>
          <CardContent>
            <WeeklyTrendChart
              quotationData={data.quotation.weeklyData}
              contractData={data.contract.weeklyData}
            />
          </CardContent>
        </Card>

        {/* 진행 현황 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">내 진행 현황</CardTitle>
          </CardHeader>
          <CardContent>
            <ProgressChart data={data.progress} />
          </CardContent>
        </Card>
      </div>

      {/* 최근 견적서 목록 */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">내 최근 견적서</CardTitle>
        </CardHeader>
        <CardContent>
          <RecentQuotationsTable userId={user.id} />
        </CardContent>
      </Card>
    </div>
  );
}

// 시간대별 인사말
function getGreeting(): string {
  const hour = new Date().getHours();
  
  if (hour < 6) return '좋은 새벽이에요';
  if (hour < 12) return '좋은 아침이에요';
  if (hour < 14) return '점심 맛있게 드세요';
  if (hour < 18) return '좋은 오후에요';
  if (hour < 22) return '좋은 저녁이에요';
  return '늦은 시간까지 수고하세요';
}
