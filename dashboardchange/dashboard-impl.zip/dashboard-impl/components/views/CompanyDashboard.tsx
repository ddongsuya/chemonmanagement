// components/dashboard/views/CompanyDashboard.tsx
// 전사 대시보드 (FULL 권한)

'use client';

import { useState } from 'react';
import { FullDashboardData, DashboardData } from '@/types/dashboard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import SummaryCard, { formatCurrency, formatPercent, calculateTrend } from '../widgets/SummaryCard';
import WeeklyTrendChart from '../widgets/WeeklyTrendChart';
import ProgressChart from '../widgets/ProgressChart';
import DepartmentTable from '../tables/DepartmentTable';
import UserRankingTable from '../tables/UserRankingTable';
import { 
  FileText, 
  FileStack, 
  Handshake, 
  TrendingUp,
  Building2,
  Users,
  User
} from 'lucide-react';

interface CompanyDashboardProps {
  data: FullDashboardData;
  personalData: DashboardData;
  user: {
    id: string;
    name: string;
    departmentName: string | null;
  };
}

export default function CompanyDashboard({ data, personalData, user }: CompanyDashboardProps) {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="space-y-6">
      {/* 상단 요약 카드 4개 */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* 총 견적 금액 */}
        <SummaryCard
          title="총 견적 금액"
          value={formatCurrency(data.quotation.totalAmount)}
          subValue={`당월 ${formatCurrency(data.quotation.currentPeriodAmount)}`}
          icon={<FileText className="h-5 w-5" />}
          trend={calculateTrend(data.quotation.weeklyData)}
        />

        {/* 발행 견적서 수 */}
        <SummaryCard
          title="발행 견적서"
          value={`${data.quotation.totalCount}건`}
          subValue={`독성 ${data.quotation.byType.toxicity.count} / 효력 ${data.quotation.byType.efficacy.count} / 임병 ${data.quotation.byType.clinicalPathology.count}`}
          icon={<FileStack className="h-5 w-5" />}
        />

        {/* 총 계약 금액 */}
        <SummaryCard
          title="총 계약 금액"
          value={formatCurrency(data.contract.totalAmount)}
          subValue={`당월 ${formatCurrency(data.contract.currentPeriodAmount)}`}
          icon={<Handshake className="h-5 w-5" />}
          trend={calculateTrend(data.contract.weeklyData)}
        />

        {/* 계약율 */}
        <SummaryCard
          title="계약율"
          value={formatPercent(data.kpi.conversionRate)}
          subValue={`평균 계약금액 ${formatCurrency(data.kpi.avgDealSize)}`}
          icon={<TrendingUp className="h-5 w-5" />}
          highlight={data.kpi.conversionRate >= 30}
        />
      </div>

      {/* 중간: 차트 2개 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 주차별 추이 차트 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">주차별 견적/계약 추이</CardTitle>
          </CardHeader>
          <CardContent>
            <WeeklyTrendChart
              quotationData={data.quotation.weeklyData}
              contractData={data.contract.weeklyData}
            />
          </CardContent>
        </Card>

        {/* 진행 현황 차트 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">진행 현황</CardTitle>
          </CardHeader>
          <CardContent>
            <ProgressChart data={data.progress} />
          </CardContent>
        </Card>
      </div>

      {/* 하단: 탭 (센터별/담당자별/내 현황) */}
      <Card>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <CardHeader className="pb-0">
            <TabsList>
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <Building2 className="h-4 w-4" />
                센터별 현황
              </TabsTrigger>
              <TabsTrigger value="users" className="flex items-center gap-2">
                <Users className="h-4 w-4" />
                담당자별 순위
              </TabsTrigger>
              <TabsTrigger value="personal" className="flex items-center gap-2">
                <User className="h-4 w-4" />
                내 현황
              </TabsTrigger>
            </TabsList>
          </CardHeader>

          <CardContent className="pt-6">
            {/* 센터별 현황 */}
            <TabsContent value="overview" className="mt-0">
              <DepartmentTable data={data.byDepartment} />
            </TabsContent>

            {/* 담당자별 순위 */}
            <TabsContent value="users" className="mt-0">
              <UserRankingTable data={data.byUser} />
            </TabsContent>

            {/* 내 현황 */}
            <TabsContent value="personal" className="mt-0">
              <PersonalSummary data={personalData} userName={user.name} />
            </TabsContent>
          </CardContent>
        </Tabs>
      </Card>
    </div>
  );
}

// 내 현황 요약 (탭 내부용)
function PersonalSummary({ data, userName }: { data: DashboardData; userName: string }) {
  return (
    <div className="space-y-4">
      <p className="text-sm text-gray-500">{userName}님의 현황</p>
      
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-blue-50 rounded-lg p-4">
          <p className="text-sm text-blue-600 font-medium">내 견적 금액</p>
          <p className="text-xl font-bold text-blue-900 mt-1">
            {formatCurrency(data.quotation.totalAmount)}
          </p>
        </div>
        
        <div className="bg-green-50 rounded-lg p-4">
          <p className="text-sm text-green-600 font-medium">내 견적서 수</p>
          <p className="text-xl font-bold text-green-900 mt-1">
            {data.quotation.totalCount}건
          </p>
        </div>
        
        <div className="bg-purple-50 rounded-lg p-4">
          <p className="text-sm text-purple-600 font-medium">내 계약 금액</p>
          <p className="text-xl font-bold text-purple-900 mt-1">
            {formatCurrency(data.contract.totalAmount)}
          </p>
        </div>
        
        <div className="bg-orange-50 rounded-lg p-4">
          <p className="text-sm text-orange-600 font-medium">내 계약율</p>
          <p className="text-xl font-bold text-orange-900 mt-1">
            {formatPercent(data.kpi.conversionRate)}
          </p>
        </div>
      </div>
    </div>
  );
}
