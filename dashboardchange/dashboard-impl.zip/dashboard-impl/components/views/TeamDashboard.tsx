// components/dashboard/views/TeamDashboard.tsx
// 부서 대시보드 (TEAM - MANAGER 권한)

'use client';

import { DashboardData } from '@/types/dashboard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import SummaryCard, { formatCurrency, formatPercent, calculateTrend } from '../widgets/SummaryCard';
import WeeklyTrendChart from '../widgets/WeeklyTrendChart';
import ProgressChart from '../widgets/ProgressChart';
import RecentQuotationsTable from '../tables/RecentQuotationsTable';
import { 
  Users, 
  User,
  FileText, 
  FileStack, 
  Handshake, 
  TrendingUp,
} from 'lucide-react';

interface TeamDashboardProps {
  teamData: DashboardData;
  personalData: DashboardData;
  user: {
    id: string;
    name: string;
    departmentName: string | null;
  };
}

export default function TeamDashboard({ teamData, personalData, user }: TeamDashboardProps) {
  return (
    <div className="space-y-6">
      {/* 부서 전체 현황 */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <Users className="h-5 w-5 text-blue-600" />
          <h2 className="text-lg font-semibold text-gray-900">
            {user.departmentName || '부서'} 전체 현황
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <SummaryCard
            title="부서 견적 금액"
            value={formatCurrency(teamData.quotation.totalAmount)}
            subValue={`당월 ${formatCurrency(teamData.quotation.currentPeriodAmount)}`}
            icon={<FileText className="h-5 w-5" />}
            trend={calculateTrend(teamData.quotation.weeklyData)}
          />

          <SummaryCard
            title="부서 견적서 수"
            value={`${teamData.quotation.totalCount}건`}
            subValue={`독성 ${teamData.quotation.byType.toxicity.count} / 효력 ${teamData.quotation.byType.efficacy.count}`}
            icon={<FileStack className="h-5 w-5" />}
          />

          <SummaryCard
            title="부서 계약 금액"
            value={formatCurrency(teamData.contract.totalAmount)}
            subValue={`당월 ${formatCurrency(teamData.contract.currentPeriodAmount)}`}
            icon={<Handshake className="h-5 w-5" />}
            trend={calculateTrend(teamData.contract.weeklyData)}
          />

          <SummaryCard
            title="부서 계약율"
            value={formatPercent(teamData.kpi.conversionRate)}
            subValue={`평균 ${formatCurrency(teamData.kpi.avgDealSize)}`}
            icon={<TrendingUp className="h-5 w-5" />}
            highlight={teamData.kpi.conversionRate >= 30}
          />
        </div>
      </div>

      <Separator />

      {/* 내 현황 */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <User className="h-5 w-5 text-green-600" />
          <h2 className="text-lg font-semibold text-gray-900">
            내 현황 ({user.name})
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <SummaryCard
            title="내 견적 금액"
            value={formatCurrency(personalData.quotation.totalAmount)}
            subValue={`당월 ${formatCurrency(personalData.quotation.currentPeriodAmount)}`}
            icon={<FileText className="h-5 w-5" />}
            trend={calculateTrend(personalData.quotation.weeklyData)}
            className="border-green-200"
          />

          <SummaryCard
            title="내 견적서 수"
            value={`${personalData.quotation.totalCount}건`}
            subValue={`독성 ${personalData.quotation.byType.toxicity.count} / 효력 ${personalData.quotation.byType.efficacy.count}`}
            icon={<FileStack className="h-5 w-5" />}
            className="border-green-200"
          />

          <SummaryCard
            title="내 계약 금액"
            value={formatCurrency(personalData.contract.totalAmount)}
            subValue={`당월 ${formatCurrency(personalData.contract.currentPeriodAmount)}`}
            icon={<Handshake className="h-5 w-5" />}
            trend={calculateTrend(personalData.contract.weeklyData)}
            className="border-green-200"
          />

          <SummaryCard
            title="내 계약율"
            value={formatPercent(personalData.kpi.conversionRate)}
            subValue={`평균 ${formatCurrency(personalData.kpi.avgDealSize)}`}
            icon={<TrendingUp className="h-5 w-5" />}
            highlight={personalData.kpi.conversionRate >= 30}
            className="border-green-200"
          />
        </div>
      </div>

      {/* 차트 & 테이블 */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* 내 주차별 추이 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">내 주차별 추이</CardTitle>
          </CardHeader>
          <CardContent>
            <WeeklyTrendChart
              quotationData={personalData.quotation.weeklyData}
              contractData={personalData.contract.weeklyData}
            />
          </CardContent>
        </Card>

        {/* 내 진행 현황 */}
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">내 진행 현황</CardTitle>
          </CardHeader>
          <CardContent>
            <ProgressChart data={personalData.progress} />
          </CardContent>
        </Card>
      </div>

      {/* 최근 견적서 */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">내 최근 견적서</CardTitle>
        </CardHeader>
        <CardContent>
          <RecentQuotationsTable userId={user.id} />
        </CardContent>
      </Card>
    </div>
  );
}
