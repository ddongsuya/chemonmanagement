# CHEMON 대시보드 권한 기반 구현

## 📦 파일 구조

```
dashboard-impl/
├── 01-schema-additions.prisma    # Prisma 스키마 추가 내용
├── 02-seed-departments.ts        # 부서 시드 데이터
├── 03-dashboard-permissions.ts   # 권한 체크 유틸리티
├── 04-dashboard-types.ts         # 타입 정의
├── 05-dashboard-api.ts           # API 엔드포인트
├── 06-use-dashboard-hook.ts      # React Hook
│
└── components/
    ├── Dashboard.tsx             # 메인 대시보드 (권한 분기)
    ├── auth/
    │   └── RegisterForm.tsx      # 회원가입 폼 (부서/직급/직책)
    ├── views/
    │   ├── PersonalDashboard.tsx # 개인 대시보드 (PERSONAL)
    │   ├── TeamDashboard.tsx     # 부서 대시보드 (TEAM)
    │   └── CompanyDashboard.tsx  # 전사 대시보드 (FULL)
    ├── widgets/
    │   ├── SummaryCard.tsx       # 요약 카드
    │   ├── WeeklyTrendChart.tsx  # 주차별 추이 차트
    │   └── ProgressChart.tsx     # 진행 현황 차트
    ├── tables/
    │   ├── DepartmentTable.tsx   # 센터별 테이블
    │   ├── UserRankingTable.tsx  # 담당자별 순위
    │   └── RecentQuotationsTable.tsx # 최근 견적서
    └── filters/
        └── PeriodFilter.tsx      # 기간 필터 (월/주/분기)
```

---

## 🚀 적용 순서

### Step 1: 스키마 수정

1. `01-schema-additions.prisma` 내용을 기존 `prisma/schema.prisma`에 추가

2. 마이그레이션 실행:
```bash
npx prisma migrate dev --name add_dashboard_permissions
```

### Step 2: 시드 데이터 추가

1. `02-seed-departments.ts`를 `prisma/seed/` 폴더에 복사

2. `prisma/seed.ts`에서 import 후 실행:
```typescript
import { seedDepartments } from './seed/departments';

async function main() {
  await seedDepartments();
  // ... 기존 시드
}
```

3. 시드 실행:
```bash
npx prisma db seed
```

### Step 3: 라이브러리 파일 복사

1. `03-dashboard-permissions.ts` → `lib/auth/dashboard-permissions.ts`
2. `04-dashboard-types.ts` → `types/dashboard.ts`

### Step 4: API 추가

1. `05-dashboard-api.ts` → `app/api/dashboard/route.ts`

### Step 5: Hook 추가

1. `06-use-dashboard-hook.ts` → `hooks/useDashboard.ts`

### Step 6: 컴포넌트 복사

1. `components/` 폴더 내용을 프로젝트 `components/dashboard/`에 복사
2. 회원가입 폼 수정 적용

### Step 7: 페이지 수정

`app/(dashboard)/dashboard/page.tsx`:
```tsx
import Dashboard from '@/components/dashboard/Dashboard';

export default function DashboardPage() {
  return <Dashboard />;
}
```

---

## ⚠️ 필요한 패키지

```bash
npm install recharts date-fns
```

---

## 🔑 권한 체계

| 조건 | 권한 | 볼 수 있는 데이터 |
|------|------|------------------|
| 일반 USER | PERSONAL | 본인만 |
| MANAGER | TEAM | 본인 + 소속 센터 합계 |
| 직책 팀장↑ | FULL | 전사 |
| 직급 부장↑ | FULL | 전사 |
| 사업지원팀 소속 | FULL | 전사 |
| ADMIN | FULL | 전사 |

---

## 📊 조직 구조

```
사업개발본부
├── 사업개발 1센터
├── 사업개발 2센터
└── 사업지원팀
```

---

## 📝 주요 기능

- ✅ 권한별 대시보드 분기 (PERSONAL / TEAM / FULL)
- ✅ 기간 필터 (월별 / 주별 / 분기별)
- ✅ 요약 카드 (견적금액, 견적수, 계약금액, 계약율)
- ✅ 주차별 추이 차트 (견적 vs 계약)
- ✅ 진행 현황 (예산확보용, 보류, 타사진행, 진행중, 협상중, 수주, 실주)
- ✅ 센터별 현황 테이블
- ✅ 담당자별 순위 테이블
- ✅ 최근 견적서 목록
- ✅ 회원가입 시 부서/직급/직책 선택

---

**작성일: 2025년 1월**
