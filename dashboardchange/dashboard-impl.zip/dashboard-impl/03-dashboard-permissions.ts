// lib/auth/dashboard-permissions.ts
// 대시보드 접근 권한 판단 유틸리티

import { Position, Title, Role } from '@prisma/client';

// =====================
// 타입 정의
// =====================

export type DashboardAccessLevel = 
  | 'PERSONAL'   // 본인 데이터만
  | 'TEAM'       // 본인 + 소속 부서 합계
  | 'FULL';      // 전사 데이터

export interface UserWithDepartment {
  id: string;
  role: Role;
  position: Position;
  title: Title;
  departmentId: string | null;
  department: {
    id: string;
    code: string;
    name: string;
  } | null;
}

export interface DataScope {
  accessLevel: DashboardAccessLevel;
  userId: string;
  departmentId?: string;
}

// =====================
// 레벨 상수
// =====================

// 직급 레벨 (부장 이상 = 5)
const POSITION_LEVELS: Record<Position, number> = {
  STAFF: 1,           // 사원
  SENIOR: 2,          // 대리
  ASSISTANT_MGR: 3,   // 과장
  DEPUTY_MGR: 4,      // 차장
  GENERAL_MGR: 5,     // 부장 ★ 전사 열람 기준
  DIRECTOR: 6,        // 이사
  SENIOR_DIR: 7,      // 상무
  EXEC_VP: 8,         // 전무
  CEO: 9,             // 대표
};

// 직책 레벨 (팀장 이상 = 4)
const TITLE_LEVELS: Record<Title, number> = {
  MEMBER: 1,          // 팀원
  SENIOR_MEMBER: 2,   // 주임
  PART_LEADER: 3,     // 파트장
  TEAM_LEADER: 4,     // 팀장 ★ 전사 열람 기준
  CENTER_HEAD: 5,     // 센터장
  DIVISION_HEAD: 6,   // 본부장
  CEO: 7,             // 대표
};

// 전사 데이터 열람 가능 부서 코드
const FULL_ACCESS_DEPT_CODES = ['BD_SUPPORT'];  // 사업지원팀

// =====================
// 권한 판단 함수
// =====================

/**
 * 사용자의 대시보드 접근 레벨을 판단합니다.
 * 
 * FULL 권한 조건 (OR):
 * - 시스템 역할이 ADMIN
 * - 소속 부서가 사업지원팀
 * - 직책이 팀장 이상
 * - 직급이 부장 이상
 * 
 * TEAM 권한 조건:
 * - 시스템 역할이 MANAGER
 * 
 * 그 외: PERSONAL
 */
export function getDashboardAccessLevel(user: UserWithDepartment): DashboardAccessLevel {
  // 1. ADMIN → 전사 열람
  if (user.role === 'ADMIN') {
    return 'FULL';
  }
  
  // 2. 사업지원팀 → 전사 열람
  if (user.department && FULL_ACCESS_DEPT_CODES.includes(user.department.code)) {
    return 'FULL';
  }
  
  // 3. 직책 팀장 이상 → 전사 열람
  if (TITLE_LEVELS[user.title] >= TITLE_LEVELS.TEAM_LEADER) {
    return 'FULL';
  }
  
  // 4. 직급 부장 이상 → 전사 열람
  if (POSITION_LEVELS[user.position] >= POSITION_LEVELS.GENERAL_MGR) {
    return 'FULL';
  }
  
  // 5. MANAGER → 본인 + 부서
  if (user.role === 'MANAGER') {
    return 'TEAM';
  }
  
  // 6. 일반 사용자 → 본인만
  return 'PERSONAL';
}

/**
 * 데이터 조회 범위를 반환합니다.
 */
export function getDataScope(user: UserWithDepartment): DataScope {
  const accessLevel = getDashboardAccessLevel(user);
  
  switch (accessLevel) {
    case 'PERSONAL':
      return { accessLevel, userId: user.id };
    case 'TEAM':
      return { 
        accessLevel, 
        userId: user.id, 
        departmentId: user.departmentId || undefined 
      };
    case 'FULL':
      return { accessLevel, userId: user.id };
  }
}

/**
 * 직급 레벨을 반환합니다.
 */
export function getPositionLevel(position: Position): number {
  return POSITION_LEVELS[position] || 1;
}

/**
 * 직책 레벨을 반환합니다.
 */
export function getTitleLevel(title: Title): number {
  return TITLE_LEVELS[title] || 1;
}

/**
 * 전사 열람 가능 부서인지 확인합니다.
 */
export function isFullAccessDepartment(deptCode: string): boolean {
  return FULL_ACCESS_DEPT_CODES.includes(deptCode);
}

// =====================
// 표시용 라벨
// =====================

export const POSITION_LABELS: Record<Position, string> = {
  STAFF: '사원',
  SENIOR: '대리',
  ASSISTANT_MGR: '과장',
  DEPUTY_MGR: '차장',
  GENERAL_MGR: '부장',
  DIRECTOR: '이사',
  SENIOR_DIR: '상무',
  EXEC_VP: '전무',
  CEO: '대표',
};

export const TITLE_LABELS: Record<Title, string> = {
  MEMBER: '팀원',
  SENIOR_MEMBER: '주임',
  PART_LEADER: '파트장',
  TEAM_LEADER: '팀장',
  CENTER_HEAD: '센터장',
  DIVISION_HEAD: '본부장',
  CEO: '대표',
};

export const ACCESS_LEVEL_LABELS: Record<DashboardAccessLevel, string> = {
  PERSONAL: '내 현황',
  TEAM: '부서 현황',
  FULL: '전사 현황',
};
