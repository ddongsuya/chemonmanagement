// prisma/seed/departments.ts
// 부서 시드 데이터

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export const departmentSeedData = [
  // 본부 (Level 0)
  {
    id: 'dept-hq',
    code: 'BD_HQ',
    name: '사업개발본부',
    level: 0,
    parentId: null,
  },
  // 센터/팀 (Level 1)
  {
    id: 'dept-center1',
    code: 'BD_CENTER1',
    name: '사업개발 1센터',
    level: 1,
    parentId: 'dept-hq',
  },
  {
    id: 'dept-center2',
    code: 'BD_CENTER2',
    name: '사업개발 2센터',
    level: 1,
    parentId: 'dept-hq',
  },
  {
    id: 'dept-support',
    code: 'BD_SUPPORT',
    name: '사업지원팀',
    level: 1,
    parentId: 'dept-hq',
  },
];

export async function seedDepartments() {
  console.log('🏢 부서 데이터 시드 시작...');

  for (const dept of departmentSeedData) {
    await prisma.department.upsert({
      where: { id: dept.id },
      update: {
        code: dept.code,
        name: dept.name,
        level: dept.level,
        parentId: dept.parentId,
      },
      create: {
        id: dept.id,
        code: dept.code,
        name: dept.name,
        level: dept.level,
        parentId: dept.parentId,
        isActive: true,
      },
    });
    console.log(`  ✅ ${dept.name} 생성/업데이트 완료`);
  }

  console.log('🏢 부서 데이터 시드 완료!');
}

// 직접 실행 시
async function main() {
  try {
    await seedDepartments();
  } catch (error) {
    console.error('❌ 시드 에러:', error);
    process.exit(1);
  } finally {
    await prisma.$disconnect();
  }
}

main();
