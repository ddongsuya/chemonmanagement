// app/api/dashboard/route.ts
// 대시보드 데이터 API

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';
import { getDashboardAccessLevel, getDataScope } from '@/lib/auth/dashboard-permissions';
import { 
  DashboardData, 
  DashboardResponse, 
  FullDashboardData,
  WeeklyData,
  ProgressData,
  PeriodParams 
} from '@/types/dashboard';

// =====================
// GET /api/dashboard
// =====================

export async function GET(request: NextRequest) {
  try {
    // 1. 인증 확인
    const session = await getServerSession(authOptions);
    if (!session?.user?.id) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // 2. 사용자 정보 조회 (부서 포함)
    const user = await prisma.user.findUnique({
      where: { id: session.user.id },
      include: { department: true },
    });

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 });
    }

    // 3. 쿼리 파라미터 파싱
    const { searchParams } = new URL(request.url);
    const periodType = (searchParams.get('periodType') || 'monthly') as 'monthly' | 'weekly' | 'quarterly';
    const year = parseInt(searchParams.get('year') || new Date().getFullYear().toString());
    const month = parseInt(searchParams.get('month') || (new Date().getMonth() + 1).toString());
    const quarter = parseInt(searchParams.get('quarter') || Math.ceil((new Date().getMonth() + 1) / 3).toString());

    const periodParams: PeriodParams = {
      type: periodType,
      year,
      month: periodType !== 'quarterly' ? month : undefined,
      quarter: periodType === 'quarterly' ? quarter : undefined,
    };

    // 4. 권한 확인
    const scope = getDataScope(user as any);

    // 5. 개인 데이터 조회
    const personalData = await getPersonalDashboardData(user.id, periodParams);

    // 6. 응답 구성
    const response: DashboardResponse = {
      accessLevel: scope.accessLevel,
      user: {
        id: user.id,
        name: user.name,
        departmentId: user.departmentId,
        departmentName: user.department?.name || null,
        position: user.position,
        title: user.title,
      },
      personal: personalData,
    };

    // 7. TEAM 이상: 부서 합계 추가
    if (scope.accessLevel !== 'PERSONAL' && user.departmentId) {
      response.team = await getTeamDashboardData(user.departmentId, periodParams);
    }

    // 8. FULL: 전사 데이터 추가
    if (scope.accessLevel === 'FULL') {
      response.company = await getCompanyDashboardData(periodParams);
    }

    return NextResponse.json(response);
  } catch (error) {
    console.error('Dashboard API error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// =====================
// 헬퍼 함수들
// =====================

/**
 * 기간 날짜 범위 계산
 */
function getPeriodDates(params: PeriodParams): { startDate: Date; endDate: Date } {
  const { type, year, month, quarter } = params;

  if (type === 'quarterly' && quarter) {
    const startMonth = (quarter - 1) * 3;
    return {
      startDate: new Date(year, startMonth, 1),
      endDate: new Date(year, startMonth + 3, 0, 23, 59, 59),
    };
  }

  // monthly 또는 weekly
  const m = month || new Date().getMonth() + 1;
  return {
    startDate: new Date(year, m - 1, 1),
    endDate: new Date(year, m, 0, 23, 59, 59),
  };
}

/**
 * 월의 주차별 데이터 범위 계산
 */
function getWeeksInMonth(year: number, month: number): Array<{ week: number; start: Date; end: Date }> {
  const weeks: Array<{ week: number; start: Date; end: Date }> = [];
  const firstDay = new Date(year, month - 1, 1);
  const lastDay = new Date(year, month, 0);

  let weekStart = new Date(firstDay);
  let weekNum = 1;

  while (weekStart <= lastDay) {
    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekEnd.getDate() + 6);

    if (weekEnd > lastDay) {
      weekEnd.setTime(lastDay.getTime());
    }

    weeks.push({
      week: weekNum,
      start: new Date(weekStart),
      end: new Date(weekEnd.setHours(23, 59, 59)),
    });

    weekStart.setDate(weekStart.getDate() + 7);
    weekNum++;
  }

  return weeks;
}

/**
 * 개인 대시보드 데이터 조회
 */
async function getPersonalDashboardData(userId: string, params: PeriodParams): Promise<DashboardData> {
  const { startDate, endDate } = getPeriodDates(params);
  const weeks = getWeeksInMonth(params.year, params.month || new Date().getMonth() + 1);

  // 견적 데이터 조회
  const quotations = await prisma.quotation.findMany({
    where: {
      createdById: userId,
      createdAt: { gte: startDate, lte: endDate },
    },
    select: {
      id: true,
      totalAmount: true,
      type: true,
      progressStatus: true,
      createdAt: true,
    },
  });

  // 계약 데이터 조회
  const contracts = await prisma.contract.findMany({
    where: {
      createdById: userId,
      createdAt: { gte: startDate, lte: endDate },
    },
    select: {
      id: true,
      totalAmount: true,
      createdAt: true,
    },
  });

  // 진행 현황 (전체 기간)
  const progressCounts = await prisma.quotation.groupBy({
    by: ['progressStatus'],
    where: { 
      createdById: userId,
      progressStatus: { not: null },
    },
    _count: true,
  });

  // 주차별 데이터 계산
  const quotationWeeklyData: WeeklyData[] = weeks.map(w => {
    const weekQuotations = quotations.filter(
      q => q.createdAt >= w.start && q.createdAt <= w.end
    );
    return {
      week: w.week,
      startDate: w.start.toISOString(),
      endDate: w.end.toISOString(),
      amount: weekQuotations.reduce((sum, q) => sum + (q.totalAmount || 0), 0),
      count: weekQuotations.length,
    };
  });

  const contractWeeklyData: WeeklyData[] = weeks.map(w => {
    const weekContracts = contracts.filter(
      c => c.createdAt >= w.start && c.createdAt <= w.end
    );
    return {
      week: w.week,
      startDate: w.start.toISOString(),
      endDate: w.end.toISOString(),
      amount: weekContracts.reduce((sum, c) => sum + (c.totalAmount || 0), 0),
      count: weekContracts.length,
    };
  });

  // 유형별 견적
  const byType = {
    toxicity: {
      count: quotations.filter(q => q.type === 'TOXICITY').length,
      amount: quotations.filter(q => q.type === 'TOXICITY').reduce((sum, q) => sum + (q.totalAmount || 0), 0),
    },
    efficacy: {
      count: quotations.filter(q => q.type === 'EFFICACY').length,
      amount: quotations.filter(q => q.type === 'EFFICACY').reduce((sum, q) => sum + (q.totalAmount || 0), 0),
    },
    clinicalPathology: {
      count: quotations.filter(q => q.type === 'CLINICAL_PATHOLOGY').length,
      amount: quotations.filter(q => q.type === 'CLINICAL_PATHOLOGY').reduce((sum, q) => sum + (q.totalAmount || 0), 0),
    },
  };

  // 진행 현황 매핑
  const progress: ProgressData = {
    budgetSecured: progressCounts.find(p => p.progressStatus === 'BUDGET_SECURED')?._count || 0,
    onHold: progressCounts.find(p => p.progressStatus === 'ON_HOLD')?._count || 0,
    withCompetitor: progressCounts.find(p => p.progressStatus === 'WITH_COMPETITOR')?._count || 0,
    inProgress: progressCounts.find(p => p.progressStatus === 'IN_PROGRESS')?._count || 0,
    negotiating: progressCounts.find(p => p.progressStatus === 'NEGOTIATING')?._count || 0,
    won: progressCounts.find(p => p.progressStatus === 'WON')?._count || 0,
    lost: progressCounts.find(p => p.progressStatus === 'LOST')?._count || 0,
  };

  // 금액 합계
  const quotationTotal = quotations.reduce((sum, q) => sum + (q.totalAmount || 0), 0);
  const contractTotal = contracts.reduce((sum, c) => sum + (c.totalAmount || 0), 0);

  // 계약율 계산
  const conversionRate = quotationTotal > 0 ? (contractTotal / quotationTotal) * 100 : 0;

  return {
    period: params,
    quotation: {
      totalAmount: quotationTotal,
      totalCount: quotations.length,
      currentPeriodAmount: quotationTotal,
      currentPeriodCount: quotations.length,
      weeklyData: quotationWeeklyData,
      byType,
    },
    progress,
    contract: {
      totalAmount: contractTotal,
      totalCount: contracts.length,
      currentPeriodAmount: contractTotal,
      currentPeriodCount: contracts.length,
      weeklyData: contractWeeklyData,
    },
    kpi: {
      conversionRate: Math.round(conversionRate * 10) / 10,
      avgDealSize: contracts.length > 0 ? Math.round(contractTotal / contracts.length) : 0,
      avgCycleTime: 0, // TODO: 계약 소요일 계산
    },
  };
}

/**
 * 부서 대시보드 데이터 조회
 */
async function getTeamDashboardData(departmentId: string, params: PeriodParams): Promise<DashboardData> {
  const { startDate, endDate } = getPeriodDates(params);
  const weeks = getWeeksInMonth(params.year, params.month || new Date().getMonth() + 1);

  // 부서 소속 사용자 ID 조회
  const departmentUsers = await prisma.user.findMany({
    where: { departmentId },
    select: { id: true },
  });
  const userIds = departmentUsers.map(u => u.id);

  // 견적 데이터 조회
  const quotations = await prisma.quotation.findMany({
    where: {
      createdById: { in: userIds },
      createdAt: { gte: startDate, lte: endDate },
    },
    select: {
      id: true,
      totalAmount: true,
      type: true,
      progressStatus: true,
      createdAt: true,
    },
  });

  // 계약 데이터 조회
  const contracts = await prisma.contract.findMany({
    where: {
      createdById: { in: userIds },
      createdAt: { gte: startDate, lte: endDate },
    },
    select: {
      id: true,
      totalAmount: true,
      createdAt: true,
    },
  });

  // 진행 현황
  const progressCounts = await prisma.quotation.groupBy({
    by: ['progressStatus'],
    where: { 
      createdById: { in: userIds },
      progressStatus: { not: null },
    },
    _count: true,
  });

  // 주차별 데이터 계산
  const quotationWeeklyData: WeeklyData[] = weeks.map(w => {
    const weekQuotations = quotations.filter(
      q => q.createdAt >= w.start && q.createdAt <= w.end
    );
    return {
      week: w.week,
      startDate: w.start.toISOString(),
      endDate: w.end.toISOString(),
      amount: weekQuotations.reduce((sum, q) => sum + (q.totalAmount || 0), 0),
      count: weekQuotations.length,
    };
  });

  const contractWeeklyData: WeeklyData[] = weeks.map(w => {
    const weekContracts = contracts.filter(
      c => c.createdAt >= w.start && c.createdAt <= w.end
    );
    return {
      week: w.week,
      startDate: w.start.toISOString(),
      endDate: w.end.toISOString(),
      amount: weekContracts.reduce((sum, c) => sum + (c.totalAmount || 0), 0),
      count: weekContracts.length,
    };
  });

  // 유형별
  const byType = {
    toxicity: {
      count: quotations.filter(q => q.type === 'TOXICITY').length,
      amount: quotations.filter(q => q.type === 'TOXICITY').reduce((sum, q) => sum + (q.totalAmount || 0), 0),
    },
    efficacy: {
      count: quotations.filter(q => q.type === 'EFFICACY').length,
      amount: quotations.filter(q => q.type === 'EFFICACY').reduce((sum, q) => sum + (q.totalAmount || 0), 0),
    },
    clinicalPathology: {
      count: quotations.filter(q => q.type === 'CLINICAL_PATHOLOGY').length,
      amount: quotations.filter(q => q.type === 'CLINICAL_PATHOLOGY').reduce((sum, q) => sum + (q.totalAmount || 0), 0),
    },
  };

  const progress: ProgressData = {
    budgetSecured: progressCounts.find(p => p.progressStatus === 'BUDGET_SECURED')?._count || 0,
    onHold: progressCounts.find(p => p.progressStatus === 'ON_HOLD')?._count || 0,
    withCompetitor: progressCounts.find(p => p.progressStatus === 'WITH_COMPETITOR')?._count || 0,
    inProgress: progressCounts.find(p => p.progressStatus === 'IN_PROGRESS')?._count || 0,
    negotiating: progressCounts.find(p => p.progressStatus === 'NEGOTIATING')?._count || 0,
    won: progressCounts.find(p => p.progressStatus === 'WON')?._count || 0,
    lost: progressCounts.find(p => p.progressStatus === 'LOST')?._count || 0,
  };

  const quotationTotal = quotations.reduce((sum, q) => sum + (q.totalAmount || 0), 0);
  const contractTotal = contracts.reduce((sum, c) => sum + (c.totalAmount || 0), 0);
  const conversionRate = quotationTotal > 0 ? (contractTotal / quotationTotal) * 100 : 0;

  return {
    period: params,
    quotation: {
      totalAmount: quotationTotal,
      totalCount: quotations.length,
      currentPeriodAmount: quotationTotal,
      currentPeriodCount: quotations.length,
      weeklyData: quotationWeeklyData,
      byType,
    },
    progress,
    contract: {
      totalAmount: contractTotal,
      totalCount: contracts.length,
      currentPeriodAmount: contractTotal,
      currentPeriodCount: contracts.length,
      weeklyData: contractWeeklyData,
    },
    kpi: {
      conversionRate: Math.round(conversionRate * 10) / 10,
      avgDealSize: contracts.length > 0 ? Math.round(contractTotal / contracts.length) : 0,
      avgCycleTime: 0,
    },
  };
}

/**
 * 전사 대시보드 데이터 조회
 */
async function getCompanyDashboardData(params: PeriodParams): Promise<FullDashboardData> {
  const { startDate, endDate } = getPeriodDates(params);
  const weeks = getWeeksInMonth(params.year, params.month || new Date().getMonth() + 1);

  // 전체 견적 데이터
  const quotations = await prisma.quotation.findMany({
    where: {
      createdAt: { gte: startDate, lte: endDate },
    },
    select: {
      id: true,
      totalAmount: true,
      type: true,
      progressStatus: true,
      createdAt: true,
      createdById: true,
      createdBy: {
        select: {
          id: true,
          name: true,
          departmentId: true,
          department: { select: { id: true, name: true } },
          position: true,
          title: true,
        },
      },
    },
  });

  // 전체 계약 데이터
  const contracts = await prisma.contract.findMany({
    where: {
      createdAt: { gte: startDate, lte: endDate },
    },
    select: {
      id: true,
      totalAmount: true,
      createdAt: true,
      createdById: true,
      createdBy: {
        select: {
          id: true,
          name: true,
          departmentId: true,
          department: { select: { id: true, name: true } },
        },
      },
    },
  });

  // 부서 목록 조회 (Level 1만 - 센터/팀)
  const departments = await prisma.department.findMany({
    where: { level: 1, isActive: true },
    orderBy: { name: 'asc' },
  });

  // 진행 현황
  const progressCounts = await prisma.quotation.groupBy({
    by: ['progressStatus'],
    where: { progressStatus: { not: null } },
    _count: true,
  });

  // 주차별 전체 데이터
  const quotationWeeklyData: WeeklyData[] = weeks.map(w => {
    const weekQuotations = quotations.filter(
      q => q.createdAt >= w.start && q.createdAt <= w.end
    );
    return {
      week: w.week,
      startDate: w.start.toISOString(),
      endDate: w.end.toISOString(),
      amount: weekQuotations.reduce((sum, q) => sum + (q.totalAmount || 0), 0),
      count: weekQuotations.length,
    };
  });

  const contractWeeklyData: WeeklyData[] = weeks.map(w => {
    const weekContracts = contracts.filter(
      c => c.createdAt >= w.start && c.createdAt <= w.end
    );
    return {
      week: w.week,
      startDate: w.start.toISOString(),
      endDate: w.end.toISOString(),
      amount: weekContracts.reduce((sum, c) => sum + (c.totalAmount || 0), 0),
      count: weekContracts.length,
    };
  });

  // 유형별
  const byType = {
    toxicity: {
      count: quotations.filter(q => q.type === 'TOXICITY').length,
      amount: quotations.filter(q => q.type === 'TOXICITY').reduce((sum, q) => sum + (q.totalAmount || 0), 0),
    },
    efficacy: {
      count: quotations.filter(q => q.type === 'EFFICACY').length,
      amount: quotations.filter(q => q.type === 'EFFICACY').reduce((sum, q) => sum + (q.totalAmount || 0), 0),
    },
    clinicalPathology: {
      count: quotations.filter(q => q.type === 'CLINICAL_PATHOLOGY').length,
      amount: quotations.filter(q => q.type === 'CLINICAL_PATHOLOGY').reduce((sum, q) => sum + (q.totalAmount || 0), 0),
    },
  };

  const progress: ProgressData = {
    budgetSecured: progressCounts.find(p => p.progressStatus === 'BUDGET_SECURED')?._count || 0,
    onHold: progressCounts.find(p => p.progressStatus === 'ON_HOLD')?._count || 0,
    withCompetitor: progressCounts.find(p => p.progressStatus === 'WITH_COMPETITOR')?._count || 0,
    inProgress: progressCounts.find(p => p.progressStatus === 'IN_PROGRESS')?._count || 0,
    negotiating: progressCounts.find(p => p.progressStatus === 'NEGOTIATING')?._count || 0,
    won: progressCounts.find(p => p.progressStatus === 'WON')?._count || 0,
    lost: progressCounts.find(p => p.progressStatus === 'LOST')?._count || 0,
  };

  const quotationTotal = quotations.reduce((sum, q) => sum + (q.totalAmount || 0), 0);
  const contractTotal = contracts.reduce((sum, c) => sum + (c.totalAmount || 0), 0);
  const conversionRate = quotationTotal > 0 ? (contractTotal / quotationTotal) * 100 : 0;

  // 부서별 데이터
  const byDepartment = departments.map(dept => {
    const deptQuotations = quotations.filter(q => q.createdBy?.departmentId === dept.id);
    const deptContracts = contracts.filter(c => c.createdBy?.departmentId === dept.id);
    const deptQuotationTotal = deptQuotations.reduce((sum, q) => sum + (q.totalAmount || 0), 0);
    const deptContractTotal = deptContracts.reduce((sum, c) => sum + (c.totalAmount || 0), 0);

    return {
      departmentId: dept.id,
      departmentCode: dept.code,
      departmentName: dept.name,
      data: {
        period: params,
        quotation: {
          totalAmount: deptQuotationTotal,
          totalCount: deptQuotations.length,
          currentPeriodAmount: deptQuotationTotal,
          currentPeriodCount: deptQuotations.length,
          weeklyData: [],
          byType: {
            toxicity: { count: 0, amount: 0 },
            efficacy: { count: 0, amount: 0 },
            clinicalPathology: { count: 0, amount: 0 },
          },
        },
        progress: { budgetSecured: 0, onHold: 0, withCompetitor: 0, inProgress: 0, negotiating: 0, won: 0, lost: 0 },
        contract: {
          totalAmount: deptContractTotal,
          totalCount: deptContracts.length,
          currentPeriodAmount: deptContractTotal,
          currentPeriodCount: deptContracts.length,
          weeklyData: [],
        },
        kpi: {
          conversionRate: deptQuotationTotal > 0 ? Math.round((deptContractTotal / deptQuotationTotal) * 1000) / 10 : 0,
          avgDealSize: deptContracts.length > 0 ? Math.round(deptContractTotal / deptContracts.length) : 0,
          avgCycleTime: 0,
        },
      },
    };
  });

  // 담당자별 데이터 (상위 10명, 견적금액 기준)
  const userQuotationMap = new Map<string, { user: any; quotationAmount: number; contractAmount: number; quotationCount: number; contractCount: number }>();

  quotations.forEach(q => {
    if (!q.createdBy) return;
    const existing = userQuotationMap.get(q.createdById) || {
      user: q.createdBy,
      quotationAmount: 0,
      contractAmount: 0,
      quotationCount: 0,
      contractCount: 0,
    };
    existing.quotationAmount += q.totalAmount || 0;
    existing.quotationCount += 1;
    userQuotationMap.set(q.createdById, existing);
  });

  contracts.forEach(c => {
    if (!c.createdBy) return;
    const existing = userQuotationMap.get(c.createdById);
    if (existing) {
      existing.contractAmount += c.totalAmount || 0;
      existing.contractCount += 1;
    }
  });

  const byUser = Array.from(userQuotationMap.values())
    .sort((a, b) => b.quotationAmount - a.quotationAmount)
    .slice(0, 10)
    .map(item => ({
      userId: item.user.id,
      userName: item.user.name,
      departmentId: item.user.departmentId || '',
      departmentName: item.user.department?.name || '-',
      position: item.user.position,
      title: item.user.title,
      data: {
        period: params,
        quotation: {
          totalAmount: item.quotationAmount,
          totalCount: item.quotationCount,
          currentPeriodAmount: item.quotationAmount,
          currentPeriodCount: item.quotationCount,
          weeklyData: [],
          byType: { toxicity: { count: 0, amount: 0 }, efficacy: { count: 0, amount: 0 }, clinicalPathology: { count: 0, amount: 0 } },
        },
        progress: { budgetSecured: 0, onHold: 0, withCompetitor: 0, inProgress: 0, negotiating: 0, won: 0, lost: 0 },
        contract: {
          totalAmount: item.contractAmount,
          totalCount: item.contractCount,
          currentPeriodAmount: item.contractAmount,
          currentPeriodCount: item.contractCount,
          weeklyData: [],
        },
        kpi: {
          conversionRate: item.quotationAmount > 0 ? Math.round((item.contractAmount / item.quotationAmount) * 1000) / 10 : 0,
          avgDealSize: item.contractCount > 0 ? Math.round(item.contractAmount / item.contractCount) : 0,
          avgCycleTime: 0,
        },
      },
    }));

  return {
    period: params,
    quotation: {
      totalAmount: quotationTotal,
      totalCount: quotations.length,
      currentPeriodAmount: quotationTotal,
      currentPeriodCount: quotations.length,
      weeklyData: quotationWeeklyData,
      byType,
    },
    progress,
    contract: {
      totalAmount: contractTotal,
      totalCount: contracts.length,
      currentPeriodAmount: contractTotal,
      currentPeriodCount: contracts.length,
      weeklyData: contractWeeklyData,
    },
    kpi: {
      conversionRate: Math.round(conversionRate * 10) / 10,
      avgDealSize: contracts.length > 0 ? Math.round(contractTotal / contracts.length) : 0,
      avgCycleTime: 0,
    },
    byDepartment,
    byUser,
  };
}
