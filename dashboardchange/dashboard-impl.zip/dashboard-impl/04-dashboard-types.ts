// types/dashboard.ts
// 대시보드 관련 타입 정의

import { QuotationProgress } from '@prisma/client';

// =====================
// 기간 관련
// =====================

export type PeriodType = 'monthly' | 'weekly' | 'quarterly';

export interface PeriodParams {
  type: PeriodType;
  year: number;
  month?: number;
  quarter?: number;
}

export interface WeeklyData {
  week: number;          // 1, 2, 3, 4, 5주차
  startDate: string;     // ISO 날짜
  endDate: string;       // ISO 날짜
  amount: number;        // 금액
  count: number;         // 건수
}

export interface QuarterlyData {
  quarter: number;       // 1, 2, 3, 4분기
  amount: number;
  count: number;
}

// =====================
// 견적 유형별 데이터
// =====================

export interface QuotationByType {
  toxicity: { count: number; amount: number };
  efficacy: { count: number; amount: number };
  clinicalPathology: { count: number; amount: number };
}

// =====================
// 진행 현황
// =====================

export interface ProgressData {
  budgetSecured: number;   // 예산확보용
  onHold: number;          // 보류
  withCompetitor: number;  // 타회사와 진행
  inProgress: number;      // 진행중
  negotiating: number;     // 협상중
  won: number;             // 수주
  lost: number;            // 실주
}

export const PROGRESS_LABELS: Record<QuotationProgress, string> = {
  BUDGET_SECURED: '예산확보용',
  ON_HOLD: '보류',
  WITH_COMPETITOR: '타회사와 진행',
  IN_PROGRESS: '진행중',
  NEGOTIATING: '협상중',
  WON: '수주',
  LOST: '실주',
};

export const PROGRESS_COLORS: Record<QuotationProgress, string> = {
  BUDGET_SECURED: '#F59E0B',   // Amber
  ON_HOLD: '#6B7280',          // Gray
  WITH_COMPETITOR: '#EF4444',  // Red
  IN_PROGRESS: '#3B82F6',      // Blue
  NEGOTIATING: '#8B5CF6',      // Purple
  WON: '#10B981',              // Green
  LOST: '#DC2626',             // Red-dark
};

// =====================
// KPI
// =====================

export interface KPIData {
  conversionRate: number;    // 계약율 (%)
  avgDealSize: number;       // 평균 계약 금액
  avgCycleTime: number;      // 평균 계약 소요일
}

// =====================
// 메인 대시보드 데이터
// =====================

export interface DashboardData {
  // 기간 정보
  period: PeriodParams;
  
  // 견적 현황
  quotation: {
    totalAmount: number;           // 총 견적 금액
    totalCount: number;            // 총 견적서 수
    currentPeriodAmount: number;   // 당월/당분기 금액
    currentPeriodCount: number;    // 당월/당분기 건수
    weeklyData: WeeklyData[];      // 주차별 데이터
    byType: QuotationByType;       // 유형별 데이터
  };
  
  // 진행 현황
  progress: ProgressData;
  
  // 계약 현황
  contract: {
    totalAmount: number;           // 총 계약 금액
    totalCount: number;            // 총 계약 건수
    currentPeriodAmount: number;   // 당월/당분기 금액
    currentPeriodCount: number;    // 당월/당분기 건수
    weeklyData: WeeklyData[];      // 주차별 데이터
  };
  
  // KPI
  kpi: KPIData;
}

// =====================
// 부서별/담당자별 데이터
// =====================

export interface DepartmentDashboardData {
  departmentId: string;
  departmentCode: string;
  departmentName: string;
  data: DashboardData;
}

export interface UserDashboardData {
  userId: string;
  userName: string;
  departmentId: string;
  departmentName: string;
  position: string;
  title: string;
  data: DashboardData;
}

// =====================
// 전사 대시보드 (FULL 권한)
// =====================

export interface FullDashboardData extends DashboardData {
  // 센터별 현황
  byDepartment: DepartmentDashboardData[];
  
  // 담당자별 현황 (상위 N명)
  byUser: UserDashboardData[];
}

// =====================
// API 응답
// =====================

export interface DashboardResponse {
  accessLevel: 'PERSONAL' | 'TEAM' | 'FULL';
  
  user: {
    id: string;
    name: string;
    departmentId: string | null;
    departmentName: string | null;
    position: string;
    title: string;
  };
  
  // 항상 포함 (개인 데이터)
  personal: DashboardData;
  
  // TEAM, FULL만 포함 (부서 합계)
  team?: DashboardData;
  
  // FULL만 포함 (전사 데이터)
  company?: FullDashboardData;
}

// =====================
// API 쿼리
// =====================

export interface DashboardQuery {
  // 기간 필터
  periodType?: PeriodType;
  year?: number;
  month?: number;
  quarter?: number;
  
  // FULL 권한자 전용 필터
  departmentId?: string;
  userId?: string;
}

// =====================
// 최근 견적서 목록
// =====================

export interface RecentQuotation {
  id: string;
  quotationNumber: string;
  customerName: string;
  type: 'TOXICITY' | 'EFFICACY' | 'CLINICAL_PATHOLOGY';
  totalAmount: number;
  status: string;
  progressStatus: QuotationProgress | null;
  createdAt: string;
}
