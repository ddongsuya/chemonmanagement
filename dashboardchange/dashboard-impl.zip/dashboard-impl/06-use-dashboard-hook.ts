// hooks/useDashboard.ts
// 대시보드 데이터 조회 Hook

import { useQuery } from '@tanstack/react-query';
import { DashboardResponse, DashboardQuery, PeriodType } from '@/types/dashboard';

// =====================
// API 호출 함수
// =====================

async function fetchDashboard(params: DashboardQuery): Promise<DashboardResponse> {
  const searchParams = new URLSearchParams();
  
  if (params.periodType) searchParams.set('periodType', params.periodType);
  if (params.year) searchParams.set('year', params.year.toString());
  if (params.month) searchParams.set('month', params.month.toString());
  if (params.quarter) searchParams.set('quarter', params.quarter.toString());
  if (params.departmentId) searchParams.set('departmentId', params.departmentId);
  if (params.userId) searchParams.set('userId', params.userId);
  
  const response = await fetch(`/api/dashboard?${searchParams.toString()}`);
  
  if (!response.ok) {
    throw new Error('Failed to fetch dashboard data');
  }
  
  return response.json();
}

// =====================
// Hook
// =====================

export interface UseDashboardParams {
  periodType?: PeriodType;
  year?: number;
  month?: number;
  quarter?: number;
  departmentId?: string;
  userId?: string;
  enabled?: boolean;
}

export function useDashboard(params: UseDashboardParams = {}) {
  const {
    periodType = 'monthly',
    year = new Date().getFullYear(),
    month = new Date().getMonth() + 1,
    quarter,
    departmentId,
    userId,
    enabled = true,
  } = params;

  return useQuery({
    queryKey: ['dashboard', { periodType, year, month, quarter, departmentId, userId }],
    queryFn: () => fetchDashboard({
      periodType,
      year,
      month: periodType !== 'quarterly' ? month : undefined,
      quarter: periodType === 'quarterly' ? quarter : undefined,
      departmentId,
      userId,
    }),
    enabled,
    staleTime: 1000 * 60 * 5, // 5분
    refetchOnWindowFocus: false,
  });
}

// =====================
// 부서 목록 조회
// =====================

async function fetchDepartments() {
  const response = await fetch('/api/departments');
  if (!response.ok) throw new Error('Failed to fetch departments');
  return response.json();
}

export function useDepartments() {
  return useQuery({
    queryKey: ['departments'],
    queryFn: fetchDepartments,
    staleTime: 1000 * 60 * 30, // 30분
  });
}

// =====================
// 최근 견적서 목록 조회
// =====================

async function fetchRecentQuotations(limit: number = 5) {
  const response = await fetch(`/api/quotations?limit=${limit}&sort=createdAt:desc`);
  if (!response.ok) throw new Error('Failed to fetch recent quotations');
  return response.json();
}

export function useRecentQuotations(limit: number = 5) {
  return useQuery({
    queryKey: ['recentQuotations', limit],
    queryFn: () => fetchRecentQuotations(limit),
    staleTime: 1000 * 60 * 2, // 2분
  });
}
